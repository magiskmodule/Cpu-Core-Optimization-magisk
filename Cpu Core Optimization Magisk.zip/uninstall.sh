rm -rf /data/powercfg.sh
rm -rf /data/powercfg.json
rm -rf /storage/emulated/0/Android/FAS